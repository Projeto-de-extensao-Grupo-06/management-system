import { faArrowUpRightFromSquare, faCopy, faFileLines, faGear, faMessage } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router'
import PageLayout from '../../components/layout/PageLayout'
import MaterialModal, { type MaterialModalData } from '../../components/materials/MaterialModal'
import type { BudgetMaterial } from '../../interfaces/types/Budget'
import BudgetService from '../../services/BudgetService'
import ClientsService from '../../services/ClientsService'
import ProjectService from '../../services/ProjectService'
import styles from './Materials.module.css'

const budgetService = new BudgetService()
const projectService = new ProjectService()
const clientsService = new ClientsService()

function normalizePhone(phone: string): string {
  const digits = phone.replace(/\D/g, '')

  if (!digits) {
    return ''
  }

  return digits.startsWith('55') ? digits : `55${digits}`
}

function getSupplierNameFromUrl(url: string): string {
  try {
    const hostname = new URL(url).hostname.replace(/^www\./, '')
    return hostname || 'Fornecedor sem nome'
  } catch {
    return 'Fornecedor sem nome'
  }
}

function formatCurrency(value: number): string {
  return value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  })
}

function buildPurchaseMessage(materials: BudgetMaterial[], clientName: string): string {
  const lines: string[] = []

  lines.push(`Olá, ${clientName || 'cliente'}!`)
  lines.push('')
  lines.push('*Lista de materiais para compra*')
  lines.push(`Data: ${new Intl.DateTimeFormat('pt-BR').format(new Date())}`)
  lines.push('')

  let total = 0

  materials.forEach((material, index) => {
    const itemTotal = material.unitPrice * material.quantity
    total += itemTotal

    lines.push(`${index + 1}. *${material.name}*`)
    lines.push(`Quantidade: ${material.quantity}`)
    lines.push(`Preço unitário: ${formatCurrency(material.unitPrice)}`)
    lines.push(`Subtotal do item: ${formatCurrency(itemTotal)}`)
    lines.push(`Link de compra: ${material.url}`)
    lines.push('')
  })

  lines.push(`*Total estimado: ${formatCurrency(total)}*`)

  return lines.join('\n')
}

function copyFallback(text: string): boolean {
  const textarea = document.createElement('textarea')
  textarea.value = text
  textarea.style.position = 'fixed'
  textarea.style.opacity = '0'

  document.body.appendChild(textarea)
  textarea.focus()
  textarea.select()

  const successful = document.execCommand('copy')
  document.body.removeChild(textarea)

  return successful
}

export default function Materials() {
  const { id } = useParams()
  const navigate = useNavigate()

  const projectId = id ? Number(id) : Number.NaN

  const [loading, setLoading] = useState(true)
  const [materials, setMaterials] = useState<BudgetMaterial[]>([])
  const [clientName, setClientName] = useState('cliente')
  const [clientPhone, setClientPhone] = useState('')
  const [message, setMessage] = useState('')
  const [feedback, setFeedback] = useState('')
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialModalData | null>(null)

  useEffect(() => {
    let active = true

    const loadData = async () => {
      if (Number.isNaN(projectId)) {
        if (active) {
          setLoading(false)
        }
        return
      }

      try {
        const budget = await budgetService.getProjectBudget(projectId)

        if (budget && active) {
          setMaterials(budget.materials)
        }

        const project = await projectService.getProjectById(String(projectId))

        if (project?.clientId) {
          const client = await clientsService.getClientById(project.clientId)
          if (active) {
            setClientName(client.name || `${client.firstName} ${client.lastName}`.trim())
            setClientPhone(client.phone)
          }
        }
      } finally {
        if (active) {
          setLoading(false)
        }
      }
    }

    loadData()

    return () => {
      active = false
    }
  }, [projectId])

  const groupedMaterials = useMemo(() => {
    const map = new Map<string, MaterialModalData>()

    materials.forEach((material) => {
      const key = material.name.trim().toLowerCase()
      const supplierId = `${key}-${material.materialUrlId}`
      const supplierName = getSupplierNameFromUrl(material.url)

      const current = map.get(key)

      if (current) {
        current.suppliers.push({
          id: supplierId,
          name: supplierName,
          url: material.url
        })
        return
      }

      map.set(key, {
        id: key,
        name: material.name,
        description: `Quantidade total prevista: ${material.quantity}`,
        category: 'Material',
        suppliers: [
          {
            id: supplierId,
            name: supplierName,
            url: material.url
          }
        ]
      })
    })

    return Array.from(map.values())
  }, [materials])

  const canGenerate = materials.length > 0

  const generatedMessage = useMemo(() => {
    if (!canGenerate) {
      return ''
    }

    return buildPurchaseMessage(materials, clientName)
  }, [canGenerate, materials, clientName])

  const messageToUse = message || generatedMessage

  function handleGenerateMessage() {
    if (!canGenerate) {
      setFeedback('Adicione materiais no orçamento para gerar a mensagem.')
      return
    }

    setMessage(generatedMessage)
    setFeedback('Mensagem gerada com sucesso.')
  }

  async function handleCopyMessage() {
    if (!messageToUse) {
      setFeedback('Gere a mensagem antes de copiar.')
      return
    }

    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(messageToUse)
      setFeedback('Mensagem copiada para a área de transferência.')
      return
    }

    const copied = copyFallback(messageToUse)
    setFeedback(copied ? 'Mensagem copiada para a área de transferência.' : 'Não foi possível copiar a mensagem.')
  }

  function handleOpenWhatsApp() {
    if (!messageToUse) {
      setFeedback('Gere a mensagem antes de enviar para o WhatsApp.')
      return
    }

    const phone = normalizePhone(clientPhone)

    if (!phone) {
      setFeedback('Telefone do cliente não encontrado para abrir o WhatsApp.')
      return
    }

    const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(messageToUse)}`
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer')
  }

  function handleEditMaterial() {
    if (!id) {
      return
    }

    navigate(`/projetos/${id}/orcamento`)
  }

  if (loading) {
    return (
      <PageLayout title="Materiais" backButton={true}>
        <div className={styles.emptyState}>Carregando materiais...</div>
      </PageLayout>
    )
  }

  if (Number.isNaN(projectId)) {
    return (
      <PageLayout title="Materiais" backButton={true}>
        <div className={styles.emptyState}>
          Para gerar lista de compra, abra a tela de materiais a partir de um projeto.
        </div>
      </PageLayout>
    )
  }

  return (
    <PageLayout
      title="Lista de Materiais"
      backButton={true}
      rightActions={
        <div className={styles.actions}>
          <button className={styles.actionButton} type="button" onClick={handleGenerateMessage}>
            <FontAwesomeIcon icon={faGear} />
            Gerar lista de materiais
          </button>

          <button className={styles.whatsappButton} type="button" onClick={handleOpenWhatsApp}>
            <FontAwesomeIcon icon={faMessage} />
            Abrir no WhatsApp
          </button>

          <button className={styles.copyButton} type="button" onClick={handleCopyMessage}>
            <FontAwesomeIcon icon={faCopy} />
            Copiar mensagem
          </button>
        </div>
      }
    >
      <div className={styles.pageGrid}>
        <section className={styles.materialsCard}>
          <header className={styles.sectionHeader}>
            <h2>
              <FontAwesomeIcon icon={faFileLines} /> Materiais no orçamento
            </h2>
            <span>{materials.length} itens</span>
          </header>

          {groupedMaterials.length === 0 ? (
            <div className={styles.emptyState}>Nenhum material encontrado neste orçamento.</div>
          ) : (
            <div className={styles.materialsList}>
              {groupedMaterials.map((material) => (
                <button
                  className={styles.materialItem}
                  key={material.id}
                  type="button"
                  onClick={() => setSelectedMaterial(material)}
                >
                  <div>
                    <strong>{material.name}</strong>
                    <p>{material.suppliers.length} fornecedor(es)</p>
                  </div>
                  <FontAwesomeIcon icon={faArrowUpRightFromSquare} />
                </button>
              ))}
            </div>
          )}
        </section>

        <section className={styles.messageCard}>
          <header className={styles.sectionHeader}>
            <h2>Mensagem pronta para envio</h2>
            <span>{clientPhone ? `WhatsApp: ${clientPhone}` : 'Telefone não encontrado'}</span>
          </header>

          <textarea
            className={styles.messagePreview}
            value={messageToUse}
            onChange={(event) => setMessage(event.target.value)}
            placeholder="Clique em 'Gerar lista de materiais' para montar a mensagem automaticamente."
          />

          {feedback ? <p className={styles.feedback}>{feedback}</p> : null}
        </section>
      </div>

      <MaterialModal
        isOpen={Boolean(selectedMaterial)}
        onClose={() => setSelectedMaterial(null)}
        material={selectedMaterial}
        onEdit={handleEditMaterial}
      />
    </PageLayout>
  )
}
